<?php
namespace App\Traits;

use DB;

/**
 * The helper trait for creating charts
 * Coding Updated By Myal Lynn Thu 5/4/2018
 * Coding Updated By Myal Lynn Thu 9/4/2018
 * Coding Updated By Myal Lynn Thu 22/4/2018
 */
trait ChartHelper {

    /**
     * The general type chart can be used to create various type of charts
     * Line, Bar, etc.
     * 
     */
    private function getChartConfig($data, $type, $labels) {
        $colors = [
            "#ffb200",
            "#0011ff",
            "#1e9b00",
            "#f2513c",
            "#93e6ff",
            "#f9ff93",
            "#f4581f"
        ];

        $result = new class{};
        $result->type = $type;
        $result->data = new class{};
        $result->data->labels = $labels;
        $result->data->datasets = [];
       

        foreach($data as $key => $value) {
            $inner_result = new class{};
            $inner_result->label = $key;
            $inner_result->data = $value;
            $inner_result->fill = (bool) 0;
            $inner_result->borderColor = $colors[array_search($key,array_keys($data))];
            $inner_result->backgroundColor = $colors[array_search($key,array_keys($data))];
            array_push($result->data->datasets, $inner_result);
        }

        $result->options = new class{};
        $result->options->responsive = (bool)1;

        return json_encode($result);
    }

    /**
     * A function that creates a pie chart
     */
    private function getPieConfig($data, $labels) {
        $colors = [
            "#ffb200",
            "#0011ff",
            "#1e9b00",
            "#f2513c",
            "#93e6ff",
            "#f9ff93",
            "#f4581f"
        ];

        $result = new class{};
        $result->type = "pie";
        $result->data = new class{};
        $result->data->labels = $labels;
        $result->data->datasets = [];
       

        foreach($data as $key => $value) {
            $inner_result = new class{};
            $inner_result->label = $key;
            $inner_result->data = $value;
            $inner_result->fill = (bool) 0;
            $inner_result->backgroundColor = array_splice($colors, 0, count($value));
            array_push($result->data->datasets, $inner_result);
        }

        $result->options = new class{};
        $result->options->responsive = (bool)1;

        return json_encode($result);
    }
    
}