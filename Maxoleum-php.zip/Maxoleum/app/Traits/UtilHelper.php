<?php
namespace App\Traits;

use DateTime;
/**
 * 
 * Coding Updated By Myint Myat Soe 24/2/2018
 * 
 * Coding Updated By Myint Myat Soe 30/2/2018
 * 
 */
trait UtilHelper {

    /**
     * Returns the full month string array from the given array of months in number
     * 
     * @return array
     * 
     */
    function getFullMonthStringFromArray($month_no_array) {
        $no_to_month = function ($value) {
            return DateTime::createFromFormat('!m', $value)->format('F');
        };

        return array_map($no_to_month, $month_no_array);
    }

    /**
     * Returns the full month string from month in number
     * 
     * @return string
     * 
     */
    function getFullMonthString($no) {
        return DateTime::createFromFormat('!m', $no)->format('F');
    }

    /**
     * Returns the values of the given associative array by the the given ids.
     * 
     * @return array
     * 
     */
    function getValuesByKeys($array, $ids) {
        $value_by_key = function($key) use ($array) {
            return $array[$key];
        };

        return array_map($value_by_key, $ids);
    }


    /**
     * Transform the given array to match generate chart in the dashboard.
     * 
     * @return array
     * 
     */
    function transformTotalSalebyOilType($array) {
        $oil_types = config('maxoleum.oil_types');
        $result = array();
        foreach($array as $a) {
            $internal =  array($oil_types[$a->oil_type] => $a->qty);
            $result = array_merge($result, $internal);
        }
        return $result;
    }
    
}