<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sale extends Model
{
    protected $fillable = [
        'payment_type',
        'oil_type',
        'date',
        'qty',
        'unit_price',
        'amount',
        'rating',
        'car_no'
    ];
}
