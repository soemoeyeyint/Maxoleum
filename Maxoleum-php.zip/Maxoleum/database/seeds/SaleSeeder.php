<?php

use Illuminate\Database\Seeder;
use Carbon\Carbon;
use App\Sale;

/**
 * Coding Updated By Aung Thu Aung 12/3/2018
 * Coding Updated By Aung Thu Aung 13/3/2018
 * Coding Updated By Aung Thu Aung 21/3/2018
 */
class SaleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $oil_types = config('maxoleum.oil_types');
        $str_date = "2016-01-01";
        $start_date = date("Y-m-d", strtotime($str_date));
        $today = date("Y-m-d");
        $daysToAdd = 0;

        $payment_type_distribution = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1];
        $rating_distribution = [null, null, 1, 2, 3, 3, 3, 3, 4, 4, 4, 5, 5];
        $prices = [800, 745, 810, 900];

        $capital_a = 65;
        $capital_z = 90;

        while($start_date <= $today) {

            $sales_count_per_day = rand(10, 20);

            for($i = 0; $i<=$sales_count_per_day; $i++) {
                $payment_type = $payment_type_distribution[rand(0, count($payment_type_distribution)-1)];
                $oil_type = rand(0, count($oil_types)-1);
                $qty = rand(3, 10);
                $unit_price = $prices[$oil_type];
                $amount = $qty * $unit_price;
                $rating = $rating_distribution[rand(0, count($rating_distribution)-1)];
                
                if($payment_type == 1) {
                    $qty = $qty * rand(7, 10);
                    $unit_price = ($unit_price - 50);
                    $amount = $qty * $unit_price * (-1);
                    $rating = null;
                }

                $sale = new Sale();
                $sale->payment_type = $payment_type;
                $sale->oil_type = $oil_type;
                $sale->date = $start_date;
                $sale->qty = $qty;
                $sale->unit_price = $unit_price;
                $sale->amount = $amount;
                $sale->car_no = rand(1, 9)
                .chr(rand($capital_a, $capital_z))
                ."/"
                .rand(1000, 9999);
                $sale->rating = $rating;
                $sale->save();
            }

            //The last part increment the date
            $daysToAdd++;
            $start_date = date("Y-m-d", strtotime($str_date. " +". $daysToAdd . " days"));
        }
    }
}
 