<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
/**
 * Coding Updated by Aung Thu Aung 1/3/2018
 * Coding Updated by Aung Thu Aung 3/3/2018
 * Coding Updated by Aung Thu Aung 15/3/2018
 */
class CreateSalesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sales', function (Blueprint $table) {
            $table->increments('id');
            $table->integer("payment_type"); //80-20 sell-buy
            $table->integer('oil_type'); // random between 0-3
            $table->date('date'); //
            $table->integer('qty')->comment('in litres');
            $table->decimal('unit_price', 12,2);
            $table->decimal('amount', 12,2);
            $table->string('car_no');
            $table->integer('rating')->nullable()->comment('1 - 5');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sales');
    }
}
