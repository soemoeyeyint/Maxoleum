{{-- Updated by  Pyae Win 3/4/2018 --}}

@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-6">
            <form action="{{route('moreInfoDBEntry')}}">
                <div class="form-group">
                    <label for="date">Date</label>
                    <input type="date" id="date" name="date" value="{{old('date')}}" class="form-control">
                </div>
                <div class="form-group">
                    <label for="car_no">Car No.</label>
                    <input type="text" id="car_no" name="car_no" value="{{old('car_no')}}" class="form-control">
                </div>
                <div class="form-group">
                    <label for="amount">Amount</label>
                    <input type="number" id="amount" name="amount" value="{{old('amount')}}" class="form-control">
                </div>
                <div class="form-group">
                <label for="sign">Sign</label>
                    <select name="sign" id="sign" class="form-control">
                        @foreach(config('maxoleum.signs') as $key=>$value)
                            <option value="{{$key}}" {{old('sign') == $key ?'selected': ''}}>{{$value}}</option>
                        @endforeach
                    </select>
                </div>
                <button class="btn btn-success" type="submit">Search</button>
            </form>
        </div>
    </div>
    <div class="row pt-5">
        <div class="col">
            <table id="table" class="table table-bordered">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Date</th>
                        <th>Payment</th>
                        <th>Oil</th>
                        <th>Qty.</th>
                        <th>Rate</th>
                        <th>Amount</th>
                        <th>Car</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($results as $index=>$value)
                    <tr>
                        <td>{{$index+1}}</td>
                        <td>{{$value->date}}</td>
                        <td>{{config('maxoleum.payment_types')[$value->payment_type]}}</td>
                        <td>{{config('maxoleum.oil_types')[$value->oil_type]}}</td>
                        <td>{{$value->qty}}</td>
                        <td>{{$value->unit_price}}</td>
                        <td>{{number_format($value->amount, 1)}}</td>
                        <td>{{$value->car_no}}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection

@push('script')
<script>
    $('#table').DataTable();
</script>
@endpush