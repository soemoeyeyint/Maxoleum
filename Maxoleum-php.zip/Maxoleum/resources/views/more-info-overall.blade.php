{{-- Updated by  Pyae Win 25/3/2018 --}}

@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row">
        {{-- Incomes --}}
        <div class="col border border-dark">
            <div class="container-fluid">
                <div class="row">
                    <div class="col">
                        <h2><strong>Incomes</strong></h2>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col">
                        Total Revenue in {{$year}}
                    </div>
                    <div class="col">
                        {{number_format($total_revenue_year, 1)}} ks
                    </div>
                </div>
                <hr>
                @if(!empty($total_revenue_month)) 
                <div class="row">
                    <div class="col">
                        Total Revenue this month in {{$year}}
                    </div>
                    <div class="col">
                        {{number_format($total_revenue_month, 1)}} ks
                    </div>
                </div>
                <hr>
                @endif
                <div class="row">
                    <div class="col">Average Revenue Per Month in {{$year}}</div>
                    <div class="col">{{number_format($avg_revenue_per_month, 1)}} ks</div>
                </div>
                <hr>
                <div class="row">
                    <div class="col">Total Profit in {{$year}}</div>
                    <div class="col"> {{number_format($gross_profit_year, 1)}} ks </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col">Average Profit per Month in {{$year}}</div>
                    <div class="col">{{number_format($avg_gross_profit_per_month, 1)}} ks</div>
                </div>
            </div>
        </div>
        <div class="col border border-dark">
            <div class="container-fluid">
                {{-- Expense --}}
                <div class="row">
                    <div class="col">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col">
                                    <h2><strong>Expenses</strong></h2>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col">Total Expense in {{$year}}</div>
                                <div class="col">{{number_format($total_expense_year, 1)}} ks</div>
                            </div>
                            <hr>
                            @if(!empty($total_expense_month))
                            <div class="row">
                                <div class="col">Total Expense this month in {{$year}}</div>
                                <div class="col">{{number_format($total_expense_month, 1)}} ks</div>
                            </div>
                            <hr>
                            @endif
                            <div class="row">
                                <div class="col">Average Expense per Month in {{$year}}</div>
                                <div class="col">{{number_format($avg_expense_per_month, 1)}} ks</div>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <hr>
                {{-- Customers --}}
                <div class="row">
                    <div class="col">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col">
                                    <h2><strong>Customers</strong></h2>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col">Total Customer in {{$year}}</div>
                                <div class="col">{{number_format($total_customers_year, 1)}}</div>
                            </div>
                            <hr>
                            @if(!empty($total_customers_month))
                            <div class="row">
                                <div class="col">Total Customer this month in {{$year}}</div>
                                <div class="col">{{number_format($total_customers_month, 1)}}</div>
                            </div>
                            <hr>
                            @endif
                            <div class="row">
                                <div class="col">Average Customer per Month in {{$year}}</div>
                                <div class="col">{{number_format($total_customers_per_month, 1)}}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col border border-dark">
            <div class="container-fluid">
                <div class="row">
                    <div class="col">
                        <h2><strong>Sales</strong></h2>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col">Total Gallon sold in {{$year}}</div>
                    <div class="col">{{number_format($total_gallons_year, 1)}}</div>
                </div>
                <hr>
                @if(!empty($total_gallons_month))
                <div class="row">
                    <div class="col">Total Gallon sold this month in {{$year}}</div>
                    <div class="col">{{number_format($total_gallons_month, 1)}}</div>
                </div>
                <hr>
                @endif
                <div class="row">
                    <div class="col">Average Gallon sold per Month in {{$year}}</div>
                    <div class="col">{{number_format($avg_gallons_per_month, 1)}}</div>
                </div>
                <hr>
                @foreach($total_sales_by_type_year as $key => $value)
                    <div class="row">
                        <div class="col">Sales of {{$key}} in {{$year}}</div>
                        <div class="col">{{number_format($value, 1)}}</div>
                    </div>
                    <hr>
                @endforeach
            </div>
        </div>
    </div>
</div>
@stop