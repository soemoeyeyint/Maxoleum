@extends('layouts.app')

@section('content')
<div class="container-fluid" id="app">
    <div class="row">
        <div class="col-12">
            <div class="container-fluid">
            <div class="row">
                <div class="col col-sm-6 offset-sm-6">
                    <form action="/dashboard" class="container-fluid">
                        <div class="row">
                            <div class="col col-sm-3">
                                <label for="year">Year</label>
                            </div>
                            <div class="col">
                                <select name="year" id="year" onchange="this.form.submit()">
                                    @foreach($years as $year)
                                    <option value="{{$year}}" {{$year == $selected_year ? "selected": ""}}>{{$year}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        
                    </form>
                </div>
            </div>
                <div class="row">
                    <div class="col-5 border border-dark">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col">
                                    <h2>Revenue and Gross Profit</h2>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col">
                                    <h3>
                                        {{$total_income}}
                                    </h3>
                                </div>
                                <div class="col">
                                    <h3>
                                        {{$gross_profit}}
                                    </h3>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <a href="{{route('moreInfoIncome')}}?year={{$selected_year}}" class="ml-auto">more info ></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 bg-white border border-dark">
                        <div class="container-fluid">
                            <div class="row"><div class="col"><h2>Customer Satisfication</h2></div></div>
                            <hr>
                            <div class="row">
                                <div class="col">
                                    <h1>{{$avg_rating}}/5</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-3 border border-dark">
                        <div class="contianer-fluid">
                            <div class="row">
                                <div class="col">
                                    <h2>Avg Customer Per Month</h2>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col justify-content-center">
                                    <h1>
                                        {{$avg_monthly_sales}}
                                    </h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-5 border border-dark">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col"><strong><h2>Monthly Sales</h2></strong></div>
                                <div class="col">
                                    <select v-model="sales_count_monthly_chart_type">
                                            <option value="line">Line</option>
                                            <option value="bar">Bar</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <canvas id="sales_count_monthly_chart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 border border-dark">
                        <div class="container-fluid">
                            {{-- Sales by Fuel type --}}
                            <div class="row">
                                <div class="col"><strong><h2>Sales By fuel Type</h2></strong></div>
                                <div class="col">
                                    <select v-model="sales_yearly_chart_type">
                                            <option value="pie">Pie</option>
                                            <option value="doughnut">Doughnut</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <canvas id="sales_yearly_chart"></canvas>   
                                </div>
                            </div>
                            <hr>

                            {{-- Sales Comparison --}}
                            <div class="row">
                                <div class="col"><strong><h2>Sales Comparison</h2></strong></div>
                                <div class="col">
                                <select v-model="sales_monthly_chart_type">
                                        <option value="line">Line</option>
                                        <option value="bar">Bar</option>
                                </select>
                                </div>
                            </div>
                            <div class="row">
                                
                                <div class="col">
                                    <canvas id="sales_monthly_chart"></canvas>
                                </div>
                            </div>
                            <hr>
                        </div>
                    </div>
                    <div class="col-3 border border-dark">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col">
                                    <h2>Statistics</h2>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col"><strong>Total Revenue in {{$selected_year}}</strong></div>
                                <div class="col">{{$total_income}}</div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col"><strong>Total Profit in {{$selected_year}} </strong></div>
                                <div class="col">{{$gross_profit}}</div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col"><strong>Total Expense in {{$selected_year}}</strong></div>
                                <div class="col">{{$total_expense}}</div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col"><strong>Total Customers in  {{$selected_year}}</strong></div>
                                <div class="col">{{$total_customers}}</div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col"><strong>Total Gallons in {{$selected_year}}</strong></div>
                                <div class="col">{{$total_gallon}}</div>
                            </div>
                            <hr>
                            @foreach($total_sales_by_type_year as $key => $value)
                                <div class="row">
                                    <div class="col"><strong>Sales in gallons of {{$key}} in {{$year}}</strong></div>
                                    <div class="col">{{$value}}</div>
                                </div>
                                <hr>
                            @endforeach

                            {{-- More Info --}}
                            <div class="row">
                                <a class="ml-auto" href="{{route('moreInfoOverAll')}}?year={{$selected_year}}">more info ></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection


@push('script')
    <script>
        var app = new Vue({
            el: "#app",
            data: {
                sales_count_monthly_chart: "",
                sales_yearly_chart: "",
                sales_monthly_chart: "",
                sales_count_monthly_chart_type: "bar",
                sales_yearly_chart_type: "pie",
                sales_monthly_chart_type: "line",
                sales_count_monthly_config: {!!$sales_count_monthly_config!!},
                sales_yearly_chart_config: {!!$sales_yearly_config!!},
                sales_monthly_chart_config: {!!$sales_monthly_conifg!!}
            },
            mounted: function() {
                this.draw_sales_count_monthly_chart(this.sales_count_monthly_chart_type);
                this.draw_sales_yearly_chart(this.sales_yearly_chart_type);
                this.draw_sales_monthly_chart(this.sales_monthly_chart_type);
            },
            methods: {
                draw_sales_count_monthly_chart: function(chart_type) {
                    var ctx = document.getElementById("sales_count_monthly_chart").getContext("2d");

                    if (this.sales_count_monthly_chart) {
                        this.sales_count_monthly_chart.destroy();
                    }

                    var temp = jQuery.extend(true, {}, this.sales_count_monthly_config);
                    temp.type = chart_type;
                    this.sales_count_monthly_chart = new Chart(ctx, temp);
                },
                draw_sales_yearly_chart: function(chart_type) {
                    var ctx = document.getElementById("sales_yearly_chart").getContext("2d");
                    
                    if (this.sales_yearly_chart) {
                        this.sales_yearly_chart.destroy();
                    }
                    
                    var temp = jQuery.extend(true, {}, this.sales_yearly_chart_config);
                    temp.type = chart_type;
                    this.sales_yearly_chart = new Chart(ctx, temp);
                },
                draw_sales_monthly_chart: function(chart_type) {
                    var ctx = document.getElementById("sales_monthly_chart").getContext("2d");
                    
                    if (this.sales_monthly_chart) {
                        this.sales_monthly_chart.destroy();
                    }
                    
                    var temp = jQuery.extend(true, {}, this.sales_monthly_chart_config);
                    temp.type = chart_type;
                    this.sales_monthly_chart = new Chart(ctx, temp);
                }
            },
            watch: {
                sales_count_monthly_chart_type: function(val) {
                    this.draw_sales_count_monthly_chart(val);
                } ,
                sales_monthly_chart_type: function(val) {
                    this.draw_sales_monthly_chart(val);
                },
                sales_yearly_chart_type: function(val) {
                    this.draw_sales_yearly_chart(val);
                }
            }
        });
    </script>



@endpush
