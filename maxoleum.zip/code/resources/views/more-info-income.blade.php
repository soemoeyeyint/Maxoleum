@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col">

            <nav>
                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                    <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Revenue</a>
                    <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Gross Profit</a>
                    </div>
                </nav>
                <div class="tab-content" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                        <div class="container">
                            <div class="row">
                                <div class="col">
                                    <h1>Revenue in {{$year}}</h1>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <div class="container border border-dark">
                                        <div class="row">
                                            <div class="col">
                                                <h2><strong>
                                                    {{$year}}
                                                </strong></h2>
                                            </div>
                                        </div>
                                        <hr>
                                        @foreach($total_income_monthly as $key => $value)
                                        <div class="row">
                                            <div class="col">{{$key}}</div>
                                            <div class="col">{{$value}}</div>   
                                        </div>
                                        <hr>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">Total Revenue</div>
                                <div class="col">{{$total_income}}</div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                        <div class="container">
                            <div class="row">
                                <div class="col">
                                    <h1>Gross Profit in {{$year}}</h1>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <div class="container border border-dark">
                                        <div class="row">
                                            <div class="col">
                                                <h2><strong>
                                                    {{$year}}
                                                </strong></h2>
                                            </div>
                                        </div>
                                        <hr>
                                        @foreach($gross_profit_monthly as $key => $value)
                                        <div class="row">
                                            <div class="col">{{$key}}</div>
                                                <div class="col">{{$value}}</div>   
                                            </div>
                                            <hr>
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">Total Gross Profit</div>
                                    <div class="col">{{$total_gross_profit}}</div>
                                </div>
                            </div>
                        </div>
                    </div>
    
        </div>
    </div>
</div>
    @stop