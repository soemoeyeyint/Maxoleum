<?php
namespace App\Traits;

use DateTime;

trait UtilHelper {
     function getFullMonthStringFromArray($month_no_array) {
        $no_to_month = function ($value) {
            return DateTime::createFromFormat('!m', $value)->format('F');
        };

        return array_map($no_to_month, $month_no_array);
    }

    function getFullMonthString($no) {
        return DateTime::createFromFormat('!m', $no)->format('F');
    }

     function getValuesByKeys($array, $ids) {
        $value_by_key = function($key) use ($array) {
            return $array[$key];
        };

        return array_map($value_by_key, $ids);
    }


     function transformTotalSalebyOilType($array) {
        $oil_types = config('maxoleum.oil_types');
        $result = array();
        foreach($array as $a) {
            $internal =  array($oil_types[$a->oil_type] => $a->qty);
            $result = array_merge($result, $internal);
        }
        return $result;
    }
    
}