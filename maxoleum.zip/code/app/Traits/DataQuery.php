<?php
namespace App\Traits;

use DB;

/**
 * 
 * A trait that works with database
 */
trait DataQuery {

    ///////////////////////////////////////////
                //Income//
    ///////////////////////////////////////////

    /**
     * Gets the monthly sales of the specified year
     * 
     * @param numeric $year
     */
    function getSalesTotalMonthly($year) {
        return DB::select(
            "SELECT  SUM(`amount`) as amount, 
            MONTH(`date`) as month 
            FROM `sales` 
            WHERE YEAR(`date`) =  {$year}
             AND payment_type = 0
            GROUP BY MONTH(`date`)"
        );
    }
    /**
     * Gets the monthly average revenue of the specified year
     * 
     * @param numeric $year
     */
    function getAvgRevenuePerMonth($year) {
        return DB::select(
            "SELECT AVG(`amount`) as avg_per_month
             from (
                 SELECT COUNT(`amount`) as amount
                  from `sales` 
                  where YEAR(`date`) = {$year} AND
                  payment_type = 0
                  GROUP BY 
                  MONTH(`date`)
                ) as avg_permonth"
        );
    }


    /**
     * Gets the total income of the specified year
     * 
     * @param numeric $year
     */
    function getTotalIncomebyYear($year) {
        return DB::select(
            "SELECT  SUM(`amount`) as amount
            FROM `sales` 
            WHERE YEAR(`date`) =  {$year}
            AND payment_type = 0"
        );
    }


    /**
     * Gets the income of the specified year and month
     * 
     * @param numeric $year
     * @param numeric $month
     */
    function getTotalIncomebyYearMonth($year, $month) {
        return DB::select(
            "SELECT  SUM(`amount`) as amount
            FROM `sales` 
            WHERE YEAR(`date`) =  {$year}
            AND payment_type = 0
            AND MONTH(`date`) = {$month}"
        );
    }

    ///////////////////////////////////////////
                //Income Ends//
    ///////////////////////////////////////////
    
    ///////////////////////////////////////////
                //Expense//
    ///////////////////////////////////////////


    /**
     * Gets the monthly expense of the specified year
     * 
     * @param numeric $year
     */
    function getAvgExpensePerMonth($year) {
        return DB::select(
            "SELECT AVG(`amount`) as avg_per_month
             from (
                 SELECT COUNT(`amount`) as amount
                  from `sales` 
                  where YEAR(`date`) = {$year} AND
                  payment_type = 1
                  GROUP BY 
                  MONTH(`date`)
                ) as avg_permonth"
        );
    }

    /**
     * Gets the total expense of the specified year
     * 
     * @param numeric $year
     */
    function getTotalExpensebyYear($year) {
        return DB::select(
            "SELECT  SUM(`amount`) as amount
            FROM `sales` 
            WHERE YEAR(`date`) =  {$year}
            AND payment_type = 1"
        );
    }


    /**
     * Gets the monthly sales of the specified year
     * 
     * @param numeric $year
     */
    function getTotalExpensebyYearMonth($year, $month) {
        return DB::select(
            "SELECT  SUM(`amount`) as amount
            FROM `sales` 
            WHERE YEAR(`date`) =  {$year} AND
            MONTH(`date`) = {$month}
            AND payment_type = 1"
        );
    }

    ///////////////////////////////////////////
                //Expense Ends//
    ///////////////////////////////////////////

    ///////////////////////////////////////////
                //Gross Profit//
    ///////////////////////////////////////////


    /**
     * Gets the monthly average gross profit of the specified year
     * 
     * @param numeric $year
     */
    function getAvgGrossProfitPerMonth($year) {
        return DB::select(
            "SELECT AVG(`amount`) as avg_per_month
             from (
                 SELECT COUNT(`amount`) as amount
                  from `sales` 
                  where YEAR(`date`) = {$year}
                  GROUP BY 
                  MONTH(`date`)
                ) as avg_permonth"
        );
    }


    /**
     * Gets the monthly gross profit of the specified year
     * 
     * @param numeric $year
     */
    function getGrossProfitMonthly($year) {
        return DB::select(
            "SELECT  SUM(`amount`) as amount, 
            MONTH(`date`) as month 
            FROM `sales` 
            WHERE YEAR(`date`) = {$year}
            GROUP BY MONTH(`date`)"
        );
    }

    /**
     * Gets the gross profit of a specified year
     * 
     * @param numeric $year
     */
    function getGrossProfitByYear($year) {
        return DB::select(
            "SELECT  SUM(`amount`) as amount
            FROM `sales` 
            WHERE YEAR(`date`) = {$year}"
        );
    }

    ///////////////////////////////////////////
                //Gross Profit Ends//
    ///////////////////////////////////////////


    ///////////////////////////////////////////
                //Rating//
    ///////////////////////////////////////////


    /**
     * Gets the monthly rating of the specified year
     * 
     * @param numeric $year
     */
    function getMonthlyAverageRating($year) {
        return DB::select(
            "SELECT  AVG(`rating`) as rating, 
            MONTH(`date`) as month 
            FROM `sales` 
            WHERE YEAR(`date`) =  {$year}
            GROUP BY MONTH(`date`)"
        );
    }

    /**
     * Gets the average rating of a specified year
     * 
     * @param numeric $year
     */
    function getAvgRating($year) {
        return DB::select(
            "SELECT AVG(`rating`) as rating 
            from `sales`
            WHERE YEAR(`date`) = {$year}"
        );
    }

    ///////////////////////////////////////////
                //Rating Ends//
    ///////////////////////////////////////////

    ///////////////////////////////////////////
                //Sales Count //
    ///////////////////////////////////////////

    /**
     * Gets the monthly average sales of the specified year
     * 
     * @param numeric $year
     */
    function getAvgMonthlySales($year) {
        return DB::select(
            "SELECT AVG(`count`) as customers
             from (
                 SELECT COUNT(*) as count
                  from `sales` 
                  where YEAR(`date`) = {$year} 
                  GROUP BY 
                  MONTH(`date`)
                ) as customers"
        );
    }

    /**
     * Gets the sales count of the specified year
     * 
     * @param numeric $year
     */
    function getSalesCount($year) {
        return DB::select(
            "SELECT count(*) as qty
            from `sales` 
            where YEAR(`date`) = {$year}"
        );
    }

    /**
     * Gets the monthly sales count of the specified year
     * 
     * @param numeric $year
     */
    function getSalesCountMonthly($year) {
        return DB::select(
            "SELECT count(*) as qty,
            MONTH(`date`) as month
            from `sales` 
            where YEAR(`date`) = {$year}
            GROUP BY MONTH(`date`)"
        );
    }

    /**
     * Gets the sales count of the specified year and month
     * 
     * @param numeric $year
     * @param numeric $month
     */
    function getSalesCountYearMonth($year, $month) {
        return DB::select(
            "SELECT count(*) as qty
            from `sales` 
            where YEAR(`date`) = {$year} AND
            MONTH(`date`) = {$month}"
        );
    }

    /**
     * Gets the monthly total gallon sold of the specified year
     * 
     * @param numeric $year
     * @param numeric $month
     */
    function getQtyCountYearMonth($year, $month) {
        return DB::select(
            "SELECT SUM(`qty`) as qty
            from `sales` 
            where YEAR(`date`) = {$year} AND
            MONTH(`date`) = {$month}"
        );
    }

    /**
     * Gets the monthly total gallon sold of the specified year and aray of oil types
     * 
     * @param numeric $year
     * @param array $oil_types
     * 
     * P.S Refer to the config/maxoleum.php for oil types
     */
    function getAllFuelSaleMonthly($year, $oil_types) {
        $result = array();
        foreach($oil_types as $key => $value) {
            array_push($result,[$value => $this->getFuelSaleMonthly($year, $key)]);
        }
        return $result;
    }

    /**
     * Gets the monthly total gallon sold of the specified year and oil type
     * 
     * @param numeric $year
     * @param numeric $oil_types
     * 
     * P.S Refer to the config/maxoleum.php for oil types
     */
    function getFuelSaleMonthly($year, $oil_type) {
        return DB::select(
            "SELECT  SUM(`qty`) as qty, 
            oil_type,
            MONTH(`date`) as month 
            FROM `sales` 
            WHERE YEAR(`date`) = {$year} AND
            `oil_type` = {$oil_type} 
            GROUP BY MONTH(`date`), oil_type"
        );
    }

    ///////////////////////////////////////////
                //Sales Count End//
    //////////////////////////////////////////

    ///////////////////////////////////////////
                //Qty//
    ///////////////////////////////////////////  

    /**
     * Gets the average monthly sales count of the specified year
     * 
     * @param numeric $year
     */
    function getAvgMonthlyGallons($year) {
        return DB::select(
            "SELECT AVG(`qty`) as gallons
             from (
                 SELECT SUM(`qty`) as qty
                  from `sales` 
                  where YEAR(`date`) = {$year} 
                  GROUP BY 
                  MONTH(`date`)
                ) as customers"
        );
    }

    /**
     * Gets the average monthly sales count of the specified year
     * 
     * @param numeric $year
     */
    function getTotalGallon($year) {
        return DB::select(
            "SELECT  SUM(`qty`) as qty, 
            oil_type
            FROM `sales` 
            WHERE YEAR(`date`) = {$year}
            GROUP BY  oil_type"
        );
    }

    /**
     * Gets the total gallon sale of a specific oil type in a specified year
     * 
     * @param numeric $year
     * @param numeric $oil_type
     * 
     * P.S Refer to the config/maxoleum.php for oil types
     */
    function getTotalQtySale($year, $oil_type) {
        return DB::select(
            "SELECT  SUM(`qty`) as qty, 
            YEAR(`date`) as year 
            FROM `sales` 
            WHERE YEAR(`date`) =  {$year}
             AND oil_type = {$oil_type}"
        );
    }

    /**
     * Get the total gallon sales in the specified year
     * 
     * @param numeric $year
     */
    function getTotalSalesbyYear($year) {
        return DB::select(
            "SELECT  SUM(`qty`) as qty, 
            YEAR(`date`) as year,
            oil_type
            FROM `sales` 
            WHERE YEAR(`date`) = {$year}
            GROUP BY oil_type, YEAR(`date`)"
        );
    }

    ///////////////////////////////////////////////
                //Qty Ends//
    ///////////////////////////////////////////////

    /**
     * Get an array of available years from database
     * 
     */
    function getYears() {
        return DB::select(
            "SELECT YEAR(`date`) as year
            From `sales` GROUP BY YEAR(`date`)"
        );
    }

    
}