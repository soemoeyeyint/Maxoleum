<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Sale;
use App\Traits\DataQuery;
use App\Traits\ChartHelper;
use App\Traits\UtilHelper;

class HomeController extends Controller
{

    use DataQuery;
    use ChartHelper;
    use UtilHelper;


    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $year = isset(request()->year) ? request()->year : date('Y');

        $oil_types = config("maxoleum.oil_types");


        $years = array_column($this->getYears(), 'year');

        //customer satisfication
        $sales_count_monthly_data_raw = $this->getSalesCountMonthly($year); 
        $sales_count_monthly_data_months = array_column($sales_count_monthly_data_raw, "month");
        $sales_count_monthly_data_refined = array_column($sales_count_monthly_data_raw, "qty");
        $sales_count_monthly_labels = $this->getFullMonthStringFromArray($sales_count_monthly_data_months);
        $sales_count_monthly_config =  $this->getChartConfig(["Monthly Sales" => $sales_count_monthly_data_refined], "bar", $sales_count_monthly_labels);


        //sales monthly
        $sales_monthly_data_raw = $this->getAllFuelSaleMonthly($year, config("maxoleum.oil_types"));
        $sales_monthly_data_refined = array();
        $sales_monthly_data_labels = [];
        reset($oil_types);
        $first = key($oil_types);
        foreach($oil_types as $key => $value) {
            $result = $this->getFuelSaleMonthly($year, $key);
            if($key == $first) {
                $sales_monthly_data_labels = $this->getFullMonthStringFromArray(array_column($result, "month"));
            }

            $sales_monthly_data_refined[$value] = array_column($result, "qty");
        }
        $sales_monthly_config = $this->getChartConfig($sales_monthly_data_refined, "line", $sales_monthly_data_labels);


        //sales yearly
        $sales_yearly_data_raw = $this->getTotalSalesbyYear($year);
        $sales_yearly_data_refined = array_column($sales_yearly_data_raw, "qty");
        $sales_yearly_data_labels = $this->getValuesByKeys($oil_types, array_column($sales_yearly_data_raw, "oil_type"));
        $sales_yearly_config = $this->getPieConfig(["Portion of Sales" => $sales_yearly_data_refined],  $sales_yearly_data_labels);


        $avg_rating = array_column($this->getAvgRating($year), "rating")[0];
        $avg_monthly_sales = array_column($this->getAvgMonthlySales($year), 'customers')[0];


        $gross_profit = array_column($this->getGrossProfitByYear($year), "amount")[0];
        $total_income = array_column($this->getTotalIncomebyYear($year), "amount")[0];
        $total_expense = array_column($this->getTotalExpensebyYear($year), "amount")[0];
        $total_gallon = array_column($this->getTotalGallon($year), "qty")[0];
        $total_customers = array_column($this->getSalesCount($year), "qty")[0];


        $total_sales_by_type_year_raw = $this->getTotalSalesbyYear($year);
        $total_sales_by_type_year = $this->transformTotalSalebyOilType($total_sales_by_type_year_raw);


         return view("home", [
             "selected_year" => $year,
             "years" => $years,
             "sales_count_monthly_config" => $sales_count_monthly_config,
             "sales_yearly_config" => $sales_yearly_config,
             "sales_monthly_conifg" => $sales_monthly_config,

             "total_income" => $total_income,
             "gross_profit" => $gross_profit,
             "avg_rating" => $avg_rating,
             "avg_monthly_sales" => $avg_monthly_sales,
             "total_expense" => $total_expense,
             "total_gallon" => $total_gallon,
             "total_customers" => $total_customers,

             "total_sales_by_type_year" => $total_sales_by_type_year
         ]); 
    }


    /**
     * Shows the over all statistics of requested year
     * 
     * @return \Illuminate\Http\Response
     */
    public function moreInfoOverAll() {
        $year =  isset(request()->year) ? request()->year : date('Y');
        $total_revenue_month = null;
        $total_expense_month = null;
        $total_customers_month = null;
        $total_gallons_month = null;

        // The year is the same as the current year
        if($year == date('Y')) {
            $month = date('m');
            
            $total_revenue_month_raw = $this->getTotalIncomebyYearMonth($year, $month);
            $total_revenue_month = array_column($total_revenue_month_raw,"amount")[0];
            
            $total_expense_month_raw = $this->getTotalExpensebyYearMonth($year, $month);
            $total_expense_month = array_column($total_expense_month_raw, "amount")[0];
            $total_expense_month = abs($total_expense_month);
            
            $total_customers_month_raw = $this->getSalesCountYearMonth($year, $month);
            $total_customers_month = array_column($total_customers_month_raw, "qty")[0];

            $total_gallons_month_raw = $this->getQtyCountYearMonth($year, $month);
            $total_gallons_month = array_column($total_gallons_month_raw, "qty")[0];
        }


        // incomes
        $total_revenue_year_raw = $this->getTotalIncomebyYear($year);
        $total_revenue_year = array_column($total_revenue_year_raw, 'amount')[0];


        $avg_revenue_per_month_raw = $this->getAvgRevenuePerMonth($year);
        $avg_revenue_per_month = array_column($avg_revenue_per_month_raw, "avg_per_month")[0];

        $gross_profit_year_raw = $this->getGrossProfitByYear($year);
        $gross_profit_year = array_column($gross_profit_year_raw, "amount")[0];
        
        $avg_gross_profit_per_month_raw = $this->getAvgGrossProfitPerMonth($year);
        $avg_gross_profit_per_month = array_column($avg_gross_profit_per_month_raw, "avg_per_month")[0];

        //Expenses
        $total_expense_year_raw = $this->getTotalExpensebyYear($year);
        $total_expense_year = array_column($total_expense_year_raw, "amount")[0];
        $total_expense_year = abs($total_expense_year);



        $avg_expense_per_month_raw = $this->getAvgExpensePerMonth($year);
        $avg_expense_per_month = array_column($avg_expense_per_month_raw, "avg_per_month")[0];
        $avg_expense_per_month = abs($avg_expense_per_month);

        //customers
        $total_customers_year_raw = $this->getSalesCount($year);
        $total_customers_year = array_column($total_customers_year_raw, "qty")[0];


        $total_customers_per_month_raw = $this->getAvgMonthlySales($year);
        $total_customers_per_month = array_column($total_customers_per_month_raw,"customers")[0];

        $total_gallons_year_raw = $this->getTotalGallon($year);
        $total_gallons_year = array_column($total_gallons_year_raw, "qty")[0];

        $avg_gallons_per_month_raw = $this->getAvgMonthlyGallons($year);
        $avg_gallons_per_month = array_column($avg_gallons_per_month_raw, "gallons")[0];

        $total_sales_by_type_year_raw = $this->getTotalSalesbyYear($year);
        $total_sales_by_type_year = $this->transformTotalSalebyOilType($total_sales_by_type_year_raw);

        return view("more-info-overall", [
            "year" => $year,

            "total_revenue_year" => $total_revenue_year,
            "avg_revenue_per_month" => $avg_revenue_per_month,
            "gross_profit_year" => $gross_profit_year,
            "avg_gross_profit_per_month" => $avg_gross_profit_per_month,

            "total_expense_year" => $total_expense_year,
            "avg_expense_per_month" => $avg_expense_per_month,

            "total_customers_year" => $total_customers_year ,
            "total_customers_per_month" => $total_customers_per_month ,

            "total_gallons_year" => $total_gallons_year ,
            "avg_gallons_per_month" => $avg_gallons_per_month ,
            "total_sales_by_type_year" => $total_sales_by_type_year,
            
            "total_revenue_month" => $total_revenue_month,
            "total_expense_month" => $total_expense_month,
            "total_customers_month" => $total_customers_month,
            "total_gallons_month" => $total_gallons_month
        ]);
    }
    

    /**
     * Shows the income statement of the requested year
     * 
     * @return \Illuminate\Http\Response
     */
    public function moreInfoIncome(){
        $year = isset(request()->year) ? request()->year : date('Y');
        
        $gross_profit_monthly_raw = $this->getGrossProfitMonthly($year);
        $gross_profit_monthly = array();
        foreach($gross_profit_monthly_raw as $value) {
            $internal = [$this->getFullMonthString($value->month) => $value->amount];
            $gross_profit_monthly = array_merge($gross_profit_monthly, $internal);
        }

        $total_gross_profit_raw = $this->getGrossProfitByYear($year);
        $total_gross_profit = array_column($total_gross_profit_raw, "amount")[0];

        $total_income_monthly_raw = $this->getSalesTotalMonthly($year);
        $total_income_monthly = array();
        foreach($total_income_monthly_raw as $value) {
            $internal = [$this->getFullMonthString($value->month) => $value->amount];
            $total_income_monthly =  array_merge($total_income_monthly, $internal);
        }

        $total_income_raw = $this->getTotalIncomebyYear($year);
        $total_income = array_column($total_income_raw, 'amount')[0];

        return view("more-info-income", [
            "year" => $year,

            "total_income_monthly" => $total_income_monthly,
            "total_income" => $total_income,

            "gross_profit_monthly" => $gross_profit_monthly,
            "total_gross_profit" => $total_gross_profit,
        ]);
    }


}
