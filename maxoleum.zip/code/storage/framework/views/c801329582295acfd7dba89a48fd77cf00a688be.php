<?php $__env->startSection('content'); ?>
<div class="container-fluid" id="app">
    <div class="row">
        <div class="col-12">
            <div class="container-fluid">
            <div class="row">
                <div class="col col-sm-6 offset-sm-6">
                    <form action="/dashboard" class="container-fluid">
                        <div class="row">
                            <div class="col col-sm-3">
                                <label for="year">Year</label>
                            </div>
                            <div class="col">
                                <select name="year" id="year" onchange="this.form.submit()">
                                    <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($year); ?>" <?php echo e($year == $selected_year ? "selected": ""); ?>><?php echo e($year); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        
                    </form>
                </div>
            </div>
                <div class="row">
                    <div class="col-5 border border-dark">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col">
                                    <h2>Revenue and Gross Profit</h2>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col">
                                    <h3>
                                        <?php echo e($total_income); ?>

                                    </h3>
                                </div>
                                <div class="col">
                                    <h3>
                                        <?php echo e($gross_profit); ?>

                                    </h3>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <a href="<?php echo e(route('moreInfoIncome')); ?>?year=<?php echo e($selected_year); ?>" class="ml-auto">more info ></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 bg-white border border-dark">
                        <div class="container-fluid">
                            <div class="row"><div class="col"><h2>Customer Satisfication</h2></div></div>
                            <hr>
                            <div class="row">
                                <div class="col">
                                    <h1><?php echo e($avg_rating); ?>/5</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-3 border border-dark">
                        <div class="contianer-fluid">
                            <div class="row">
                                <div class="col">
                                    <h2>Avg Customer Per Month</h2>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col justify-content-center">
                                    <h1>
                                        <?php echo e($avg_monthly_sales); ?>

                                    </h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-5 border border-dark">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col"><strong><h2>Monthly Sales</h2></strong></div>
                                <div class="col">
                                    <select v-model="sales_count_monthly_chart_type">
                                            <option value="line">Line</option>
                                            <option value="bar">Bar</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <canvas id="sales_count_monthly_chart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 border border-dark">
                        <div class="container-fluid">
                            
                            <div class="row">
                                <div class="col"><strong><h2>Sales By fuel Type</h2></strong></div>
                                <div class="col">
                                    <select v-model="sales_yearly_chart_type">
                                            <option value="pie">Pie</option>
                                            <option value="doughnut">Doughnut</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <canvas id="sales_yearly_chart"></canvas>   
                                </div>
                            </div>
                            <hr>

                            
                            <div class="row">
                                <div class="col"><strong><h2>Sales Comparison</h2></strong></div>
                                <div class="col">
                                <select v-model="sales_monthly_chart_type">
                                        <option value="line">Line</option>
                                        <option value="bar">Bar</option>
                                </select>
                                </div>
                            </div>
                            <div class="row">
                                
                                <div class="col">
                                    <canvas id="sales_monthly_chart"></canvas>
                                </div>
                            </div>
                            <hr>
                        </div>
                    </div>
                    <div class="col-3 border border-dark">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col">
                                    <h2>Statistics</h2>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col"><strong>Total Revenue in <?php echo e($selected_year); ?></strong></div>
                                <div class="col"><?php echo e($total_income); ?></div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col"><strong>Total Profit in <?php echo e($selected_year); ?> </strong></div>
                                <div class="col"><?php echo e($gross_profit); ?></div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col"><strong>Total Expense in <?php echo e($selected_year); ?></strong></div>
                                <div class="col"><?php echo e($total_expense); ?></div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col"><strong>Total Customers in  <?php echo e($selected_year); ?></strong></div>
                                <div class="col"><?php echo e($total_customers); ?></div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col"><strong>Total Gallons in <?php echo e($selected_year); ?></strong></div>
                                <div class="col"><?php echo e($total_gallon); ?></div>
                            </div>
                            <hr>
                            <?php $__currentLoopData = $total_sales_by_type_year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col"><strong>Sales in gallons of <?php echo e($key); ?> in <?php echo e($year); ?></strong></div>
                                    <div class="col"><?php echo e($value); ?></div>
                                </div>
                                <hr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                            <div class="row">
                                <a class="ml-auto" href="<?php echo e(route('moreInfoOverAll')); ?>?year=<?php echo e($selected_year); ?>">more info ></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        var app = new Vue({
            el: "#app",
            data: {
                sales_count_monthly_chart: "",
                sales_yearly_chart: "",
                sales_monthly_chart: "",
                sales_count_monthly_chart_type: "bar",
                sales_yearly_chart_type: "pie",
                sales_monthly_chart_type: "line",
                sales_count_monthly_config: <?php echo $sales_count_monthly_config; ?>,
                sales_yearly_chart_config: <?php echo $sales_yearly_config; ?>,
                sales_monthly_chart_config: <?php echo $sales_monthly_conifg; ?>

            },
            mounted: function() {
                this.draw_sales_count_monthly_chart(this.sales_count_monthly_chart_type);
                this.draw_sales_yearly_chart(this.sales_yearly_chart_type);
                this.draw_sales_monthly_chart(this.sales_monthly_chart_type);
            },
            methods: {
                draw_sales_count_monthly_chart: function(chart_type) {
                    var ctx = document.getElementById("sales_count_monthly_chart").getContext("2d");

                    if (this.sales_count_monthly_chart) {
                        this.sales_count_monthly_chart.destroy();
                    }

                    var temp = jQuery.extend(true, {}, this.sales_count_monthly_config);
                    temp.type = chart_type;
                    this.sales_count_monthly_chart = new Chart(ctx, temp);
                },
                draw_sales_yearly_chart: function(chart_type) {
                    var ctx = document.getElementById("sales_yearly_chart").getContext("2d");
                    
                    if (this.sales_yearly_chart) {
                        this.sales_yearly_chart.destroy();
                    }
                    
                    var temp = jQuery.extend(true, {}, this.sales_yearly_chart_config);
                    temp.type = chart_type;
                    this.sales_yearly_chart = new Chart(ctx, temp);
                },
                draw_sales_monthly_chart: function(chart_type) {
                    var ctx = document.getElementById("sales_monthly_chart").getContext("2d");
                    
                    if (this.sales_monthly_chart) {
                        this.sales_monthly_chart.destroy();
                    }
                    
                    var temp = jQuery.extend(true, {}, this.sales_monthly_chart_config);
                    temp.type = chart_type;
                    this.sales_monthly_chart = new Chart(ctx, temp);
                }
            },
            watch: {
                sales_count_monthly_chart_type: function(val) {
                    this.draw_sales_count_monthly_chart(val);
                } ,
                sales_monthly_chart_type: function(val) {
                    this.draw_sales_monthly_chart(val);
                },
                sales_yearly_chart_type: function(val) {
                    this.draw_sales_yearly_chart(val);
                }
            }
        });
    </script>



<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>