<?php

return [
    "oil_types" => [
        "diesel",
        "octane-92",
        "octane-95",
        "octane-97"
    ],
    "payment_types" => [
        "income",
        "expense"
    ], 
];