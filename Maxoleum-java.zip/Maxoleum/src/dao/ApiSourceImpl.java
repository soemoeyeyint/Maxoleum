/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.io.File;
import java.io.IOException;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import utils.LogHelper;



/**
 *
 * @author Soe Moe Ye Yint
 */
public class ApiSourceImpl implements ApiSource{
    
    @Override
    public String uploadFile(String url, File file, String key) {
        try {
            CloseableHttpClient httpclient = HttpClients.createDefault();
            
            // build upload request
            HttpEntity data = MultipartEntityBuilder.create()
                    .addBinaryBody(key, file, ContentType.TEXT_PLAIN, file.getName())
                    .build();
            
            // build http request and assign multipart upload data
            HttpUriRequest request = RequestBuilder
                    .post(url)
                    .setEntity(data)
                    .build();
            
            
            // Create a custom response handler
            ResponseHandler<String> responseHandler = response -> {
                int status = response.getStatusLine().getStatusCode();
                if (status >= 200 && status < 300) {
                    HttpEntity entity = response.getEntity();
                    return entity != null ? EntityUtils.toString(entity) : null;
                } else {
                    throw new ClientProtocolException("Unexpected response status: " + status);
                }
            };
            
            return httpclient.execute(request, responseHandler);
        } catch (IOException ex) {
            LogHelper.error(ex.getMessage());
        }
        return null;
    }

}
