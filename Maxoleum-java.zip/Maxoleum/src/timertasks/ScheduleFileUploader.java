/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package timertasks;

import dao.ApiSource;
import dao.ApiSourceImpl;
import java.io.File;
import java.util.TimerTask;
import utils.LogHelper;
import utils.PropertyHelper;
import java.time.LocalTime;
import static java.time.temporal.ChronoUnit.MILLIS;
import java.util.Timer;

/**
 * This class uploads the file on schedule
 * @author Soe Moe Ye Yint
 */
public class ScheduleFileUploader {

    private Timer timer;

    public ScheduleFileUploader() {
        timer = new Timer();
    }

    /**
     *  Loads the timer and schedule the task
     */
    public void loadAndSchedule() {
        PropertyHelper prop_helpr = new PropertyHelper();
        String hr = prop_helpr.getValue(PropertyHelper.KEY_UPLOAD_HOUR);
        String min = prop_helpr.getValue(PropertyHelper.KEY_UPLOAD_MINUTES);
        LocalTime l_now = LocalTime.now();
        LocalTime l_time = LocalTime.of(Integer.parseInt(hr), Integer.parseInt(min));

        long delay = Math.abs(MILLIS.between(l_now, l_time));
        long hr24 = 1000L * 60L * 60L * 24L;
        timer.scheduleAtFixedRate(new ScheduleTimerTask(), delay, hr24);
    }

    /**
     * Cancels the timer tasks
     */
    public void cancel() {
        timer.cancel();
    }


    /**
     * Reloads the properties file
     */
    public void reload() {
        cancel();
        loadAndSchedule();
    }
    
    /**
     * Internal class that ScheduleFileUploader uses for scheduling
     */
    class ScheduleTimerTask extends TimerTask {

        @Override
        public void run() {
            ApiSource apiSource = new ApiSourceImpl();
            PropertyHelper propHelper = new PropertyHelper();
            String url = propHelper.getValue(PropertyHelper.KEY_URL);
            //String name = propHelper.getValue(ApiSource.FILE_NAME);
            String name = "jsonFile";
            File file = new File(propHelper.getValue(PropertyHelper.KEY_UPLOAD_FILE_PATH));
            if (file.exists() && file.isFile()) {
                apiSource.uploadFile(url, file, name);
                LogHelper.info("File Uploaded");
            } else {
                LogHelper.error("FILE DOES NOT EXIST.");
            }
        }
    }
}
