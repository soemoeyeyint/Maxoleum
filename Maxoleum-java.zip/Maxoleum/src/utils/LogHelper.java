/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import org.apache.log4j.Logger;

/**
 *
 * @author Soe Moe Ye Yint
 */
public class LogHelper {
    private static final Logger logger = Logger.getLogger(LogHelper.class);
    
    /**
     * Log Debugs messages
     * 
     * @param message 
     */
    public static void debug(Object message) {
        logger.debug(message);
    }
    
    /**
     * Log errors
     * 
     * @param error 
     */
    public static void error(Object error) {
        logger.error(error);
    }
    
    /**
     * Log information
     * @param info 
     */
    public static void info(Object info) {
        logger.info(info);
    }
}
