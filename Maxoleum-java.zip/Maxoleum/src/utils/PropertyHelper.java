/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

/**
 *
 * @author Soe Moe Ye Yint
 */
public class PropertyHelper {
   
   public static final String KEY_URL = "url";
   public static final String KEY_UPLOAD_HOUR = "upload_hour";
   public static final String KEY_UPLOAD_MINUTES  = "upload_minute";
   public static final String KEY_UPLOAD_FILE_PATH = "upload_file_path";
   
   public static final String DEFAULT_URL = "localhost:8000/api/file-upload";
   public static final String DEFAULT_UPLOAD_HOUR = "20";
   public static final String DEFAULT_UPLOAD_MINUTE = "00";
   public static final String DEFAULT_FILE_PATH =  "data/data.json";
   public static final String DEFAULT_UPLOAD_FILE_NAME = "jsonFile";
   
   public static final String PROP_LOCATION = "maxoleum.properties";
   
   private Properties prop;
   private OutputStream outStream;
   
   
   /**
    * Create new record if none exist.
    * 
    * @param key
    * @param value
    * @return boolean
    */
   public boolean setValue(String key, String value) {
       OutputStream outStream = null;
       InputStream inStream = null;
       
       try{
           inStream = new FileInputStream(PROP_LOCATION);
           prop.load(inStream);
           prop.setProperty(key, value);
           outStream = new FileOutputStream(PROP_LOCATION);
           prop.store(outStream, null);
       } catch(FileNotFoundException e) {
           LogHelper.error(e.getMessage());
       } catch(IOException e) {
           LogHelper.error(e.getMessage());
       } finally {
           try {
               inStream.close();
               outStream.close();
           } catch(IOException e) {
               LogHelper.error(e.getMessage());
           }
       }
       return false;
   }
   
   /**
    * Get the value of the given key. If no value is found, returns null.
    * 
    * @param key
    * @return 
    */
   public String getValue(String key) {
       String result = null;
       FileInputStream inStream = null;
       try{
           inStream = new FileInputStream(PROP_LOCATION);
           
           prop.load(inStream);
           result = prop.getProperty(key);
       } catch(FileNotFoundException e) {
           LogHelper.error(e.getMessage());
       } catch(IOException e) {
           LogHelper.error(e.getMessage());
       }
       return result;
   }
   
   
   public void createDefaultIfNotExist() {

   }
   
   /**
    * Creates the properties file with default values
    * 
    */
   public void createPropWithDefault() {
       OutputStream outStream = null;
        try {
            outStream = new FileOutputStream(PROP_LOCATION);
            
            prop.setProperty(KEY_URL, DEFAULT_URL);
            prop.setProperty(KEY_UPLOAD_FILE_PATH, DEFAULT_FILE_PATH);
            prop.setProperty(KEY_UPLOAD_HOUR, DEFAULT_UPLOAD_HOUR);
            prop.setProperty(KEY_UPLOAD_MINUTES, DEFAULT_UPLOAD_MINUTE);
            
            prop.store(outStream, null);
            LogHelper.info("The properties file has been created with default values");
        } catch(FileNotFoundException e) {
            LogHelper.error(e.getMessage());
        } catch(IOException e) {
            LogHelper.error(e.getMessage());
        }
   }
   
   public PropertyHelper()  {
       this.prop = new Properties();
   }
}  
