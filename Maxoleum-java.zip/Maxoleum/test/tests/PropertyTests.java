/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tests;

import java.io.File;
import junit.framework.Assert;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import utils.PropertyHelper;

/**
 *
 * @author 
 * This test is to be tested with default values from test 1 
 */
public class PropertyTests {
    PropertyHelper prop;
    
    @Before
    public void beforeTests() {
        prop = new PropertyHelper();
    }

     @Test
     public void propertyCreateTest_1() {
        prop.createPropWithDefault();
        org.junit.Assert.assertTrue(new File(PropertyHelper.PROP_LOCATION).exists()); 
     }
     
     @Test
     public void propertyKeyValueTest_2() {
         prop.setValue("hello", "greeting");
         
         String result = prop.getValue("hello");
         Assert.assertEquals("greeting", result);
     }
}
