/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tests;

import dao.ApiSource;
import dao.ApiSourceImpl;
import java.io.File;
import junit.framework.Assert;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import utils.LogHelper;
import utils.PropertyHelper;

/**
 *
 * @author zaymi
 */
public class ApiCallTest {
    
    ApiSourceImpl apiSource;
    PropertyHelper propHelper;
    
    @Before
    public void setUp() {
        apiSource = new ApiSourceImpl();
        propHelper = new PropertyHelper();
    }

    /**
     * Success Test
     */
     @Test
     public void fileUploadTest_1() {
         String url = "http://httpbin.org/post";
         File file = new File(PropertyHelper.DEFAULT_FILE_PATH);
         String response = apiSource.uploadFile(url, file, "testing_file");
         System.out.println(response);
         Assert.assertNotNull(response);
     }
     
     
     /**
      * Fail Test
      */
     @Test
     public void fileUploadTest_2() {
         String url = "http://httpbin.org/postblabla";
         File file = new File(PropertyHelper.DEFAULT_FILE_PATH);
         String response = apiSource.uploadFile(url, file, "testing_file");
         System.out.println(response);
         Assert.assertNull(response);
     }
     
     /**
      * Test if log4j is working
      * Check the file according to the log4j.properties
      */
     @Test
     public void fileUploadTest_3() {
        String url = "http://httpbin.org/post";
        String name = ApiSource.FILE_NAME;
        File file = new File("blabla"); 
        if(file.exists() && file.isFile()) {
            apiSource.uploadFile(url, file, name);
            LogHelper.info("File Uploaded");
        } else {
            LogHelper.error("FILE DOES NOT EXIST.");
        }
     }
     
     /**
      * 
      * Success Test if the file exits
      * 
      */
     @Test
     public void fileUploadTest_4() {
        String url = "http://httpbin.org/post";
        String name = ApiSource.FILE_NAME;
        File file = new File(propHelper.getValue(PropertyHelper.KEY_UPLOAD_FILE_PATH)); 
        if(file.exists() && file.isFile()) {
            apiSource.uploadFile(url, file, name);
            LogHelper.info("File Uploaded");
        } else {
            LogHelper.error("FILE DOES NOT EXIST.");
        }
     }
}
